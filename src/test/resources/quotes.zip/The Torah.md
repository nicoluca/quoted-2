# The Torah

- Hear, O Israel: The LORD our God, the LORD is one.
- You shall love the LORD your God with all your heart and with all your soul and with all your might.
- And these words that I command you today shall be on your heart.
- Remember the Sabbath day, to keep it holy.
- You shall not murder.
- You shall not steal.
- You shall not take the name of the LORD your God in vain.
- Honor your father and your mother.
