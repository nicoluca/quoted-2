# The Tibetan Book of the Dead

- The nature of the mind is clear light; it is unproduced and unobstructed.
- When a person dies, the mind's clarity, the luminosity of the mind, dawns.
- The essential nature of mind is without birth or cessation; it is empty and without identity.
- Let the winds of the heavens now arise; let the winds blow away my sins.
- May I attain the transcendental wisdom of the Great Perfection, in which all doubts are clarified.
- May I recognize whatever appears as my projection, and may I understand the nature of the illusion-like phenomena of the six realms.
- May I attain the power to dissolve the body of delusion into the expanse of the ground.
