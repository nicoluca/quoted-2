# The Quran

- And We have certainly created man from clay of altered black mud.
- And We have certainly created man in the best of stature.
- And We have certainly created man and We know what his soul whispers to him, and We are closer to him than [his] jugular vein.
- Say, "He is Allah, [who is] One, Allah, the Eternal Refuge.
- Allah does not burden a soul beyond that it can bear.
- And when My servants ask you concerning Me, indeed I am near. I respond to the invocation of the supplicant when he calls upon Me.
- And We have certainly created man in a best form.
- And Allah is the best of planners.
- And We have certainly created man from a sperm-drop mixture so that We may test him.
- And whoever is patient and forgives - indeed, that is of the matters [requiring] determination.
