# The Bible

- For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.
- For it is by grace you have been saved, through faith—and this is not from yourselves, it is the gift of God— not by works, so that no one can boast.
- For the wages of sin is death, but the gift of God is eternal life in Christ Jesus our Lord.
- For God is not a God of confusion but of peace.
- Trust in the LORD with all your heart, and do not lean on your own understanding.
- Do not be anxious about anything, but in everything by prayer and supplication with thanksgiving let your requests be made known to God.
- In all your ways acknowledge him, and he will make straight your paths.
- Love is patient and kind; love does not envy or boast; it is not arrogant or rude.
- Rejoice in the Lord always. I will say it again: Rejoice!
- The Lord is my shepherd; I shall not want.
- Let us not become weary in doing good, for at the proper time we will reap a harvest if we do not give up.
- Do not be overcome by evil, but overcome evil with good.
- Commit to the LORD whatever you do, and he will establish your plans.
